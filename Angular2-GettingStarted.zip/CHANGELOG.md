#Changes made to the course since its release:
- None

#Changes made to the sample code:
- 4/24/16 Replace deprecated "concurrent" command with "concurrently"
- 4/14/16 Brought up to Beta 15 (this only affected the boilerplate code)
- 5/9/16  Added `APM - Final Updated` to provide files updated to later versions (includes breaking changes from what is shown in the course demos.)

#Changes made to `APM - Final Updated`:
- 5/9/16  Updated to Beta 16 including changes to the signature for the custom pipe implementation.
- 5/9/16  Updated to Beta 17 including changes to ngFor to use `let` instead of `#`.
- 5/9/16  Updated to Release Candidate (RC) 1 including all new starter files and change to @angular npm scoped packages. This uses the router-deprecated to match the routing presented in the course.
- 5/9/16  Updated to the RC component router.
